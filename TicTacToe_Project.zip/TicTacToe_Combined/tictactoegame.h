#ifndef TICTACTOEGAME_H
#define TICTACTOEGAME_H

#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMessageBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QListWidgetItem>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QButtonGroup>
#include <QtCore/QTimer>
#include <QtGui/QBrush>
#include <QtGui/QColor>
#include <QtGui/QFont>
#include <QtCore/QCryptographicHash>
#include <vector>
#include <string>
#include <stack>
#include <list>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <ctime>
#include <random>
#include <climits>
#include <chrono>
#include <iomanip>
#include <memory>
#include <functional>

// Forward declarations
class GameBoard;
class AIPlayer;
class UserHashTable;
class GameHistory;
class GameStateStack;

// Enumerations
enum class GameState {
    MENU,
    LOGIN,
    REGISTER,
    GAME_MODE_SELECTION,
    SYMBOL_SELECTION,
    DIFFICULTY_SELECTION,
    PLAYING,
    GAME_HISTORY,
    REPLAY_MODE,
    SETTINGS
};

enum class PlayerType {
    HUMAN,
    AI
};

enum class GameResult {
    PLAYER1_WIN,
    PLAYER2_WIN,
    AI_WIN,
    HUMAN_WIN,
    TIE,
    ONGOING
};

enum class GameMode {
    PLAYER_VS_PLAYER,
    PLAYER_VS_AI
};

enum class ThemeMode {
    LIGHT,
    DARK
};

enum class DifficultyLevel {
    EASY,
    MEDIUM,
    HARD
};

// Structures
struct Move {
    int row;
    int col;
    char player;
    std::string timestamp;
    int moveNumber;

    Move() : row(-1), col(-1), player(' '), moveNumber(-1) {}
    Move(int r, int c, char p) : row(r), col(c), player(p), moveNumber(-1) {}
    Move(int r, int c, char p, const std::string& time, int num)
        : row(r), col(c), player(p), timestamp(time), moveNumber(num) {}
};

struct User {
    std::string username;
    std::string passwordHash;
    int gamesPlayed;
    int gamesWon;
    int gamesLost;
    int gamesTied;

    User() : gamesPlayed(0), gamesWon(0), gamesLost(0), gamesTied(0) {}
    User(const std::string& user, const std::string& pass)
        : username(user), passwordHash(pass), gamesPlayed(0), gamesWon(0), gamesLost(0), gamesTied(0) {}
};

struct GameRecord {
    std::string player1;
    std::string player2;
    GameMode mode;
    GameResult result;
    std::vector<std::vector<char>> finalBoard;
    std::string timestamp;
    std::vector<Move> moves;

    GameRecord() = default;
    GameRecord(const std::string& p1, const std::string& p2, GameMode m, GameResult r,
               const std::vector<std::vector<char>>& board, const std::string& time)
        : player1(p1), player2(p2), mode(m), result(r), finalBoard(board), timestamp(time) {}
};

// Hash Table for User Management
class UserHashTable {
private:
    static const int BUCKET_SIZE = 100;
    std::list<std::pair<std::string, User>> table[BUCKET_SIZE];

    int hashFunction(const std::string& key);

public:
    UserHashTable();
    ~UserHashTable();

    bool insertUser(const std::string& username, const std::string& passwordHash);
    bool authenticateUser(const std::string& username, const std::string& passwordHash);
    bool userExists(const std::string& username);
    void removeUser(const std::string& username);
    User* getUser(const std::string& username);
    void updateUser(const std::string& username, const User& user);
    std::vector<std::string> getAllUsers();
    void loadUsers();
    void saveUsers();
    void clear();
};

// Stack for Game State Management
class GameStateStack {
private:
    std::stack<Move> moveStack;
    std::stack<std::vector<std::vector<char>>> boardStateStack;

public:
    GameStateStack();
    ~GameStateStack();

    void pushMove(const Move& move, const std::vector<std::vector<char>>& boardState);
    Move popMove();
    std::vector<std::vector<char>> popBoardState();
    bool canUndo();
    void clearStack();
    size_t size();
    Move topMove();
    std::vector<std::vector<char>> topBoardState();
};

// Game Board Class
class GameBoard {
public:
    GameBoard();
    void reset();
    bool makeMove(int row, int col, char player);
    char getCell(int row, int col) const;
    GameResult checkWin() const;
    bool isFull() const;
    std::vector<std::pair<int, int>> getAvailableMoves() const;
    std::vector<std::vector<char>> getBoard() const;
    void setBoard(const std::vector<std::vector<char>>& board);

private:
    std::vector<std::vector<char>> board;
    static const int BOARD_SIZE = 3;
};

// AI Player Class
class AIPlayer {
public:
    AIPlayer(char aiSymbol, char humanSymbol, DifficultyLevel difficulty = DifficultyLevel::HARD);
    std::pair<int, int> getBestMove(const GameBoard& board);
    void setDifficulty(DifficultyLevel difficulty);
    void pushAIMove(int row, int col);
    std::pair<int, int> popAIMove();
    bool hasAIMoveHistory();
    void clearAIMoveHistory();

private:
    int minimax(GameBoard& board, int depth, bool isMaximizing, int alpha, int beta);
    int evaluateBoard(const GameBoard& board);
    std::pair<int, int> getRandomMove(const GameBoard& board);
    std::pair<int, int> getMediumMove(const GameBoard& board);
    std::pair<int, int> getHardMove(const GameBoard& board);
    std::pair<int, int> getCriticalMove(const GameBoard& board);
    std::pair<int, int> getLimitedMinimax(const GameBoard& board, int maxDepth);
    int limitedMinimax(GameBoard& board, int depth, bool isMaximizing, int alpha, int beta, int maxDepth);
    int evaluatePosition(const GameBoard& board);
    int evaluateLine(char cell1, char cell2, char cell3);

    char aiSymbol;
    char humanSymbol;
    DifficultyLevel currentDifficulty;
    static const int MAX_DEPTH = 9;
    std::stack<std::pair<int, int>> aiMoveHistory;
};

class GameHistory {
public:
    GameHistory();
    void addGameRecord(const GameRecord& record);
    std::vector<GameRecord> getUserGames(const std::string& username);
    std::vector<GameRecord> getAllGames();
    void saveHistory();
    void loadHistory();

private:
    std::vector<GameRecord> gameRecords;
    std::string historyFile;
    std::string getCurrentTimestamp();
    void loadHistoryIfNeeded();
};

// Main Game Class
class TicTacToeGame : public QMainWindow {
    Q_OBJECT

public:
    TicTacToeGame(QWidget *parent = nullptr);
    ~TicTacToeGame();

private slots:
    void onLoginClicked();
    void onRegisterClicked();
    void onBackToMenuClicked();
    void onPlayerVsPlayerClicked();
    void onPlayerVsAIClicked();
    void onGameHistoryClicked();
    void onCellClicked();
    void onNewGameClicked();
    void onLogoutClicked();
    void onShowRegisterClicked();
    void onShowLoginClicked();
    void onReplayGameClicked();
    void onReplayNextClicked();
    void onReplayPrevClicked();
    void onReplayBackClicked();
    void onReplayAutoPlayClicked();
    void onSettingsClicked();
    void onThemeChanged();
    void onBackFromSettingsClicked();
    void onSymbolSelectionClicked();
    void onBackFromSymbolSelectionClicked();
    void onDifficultySelectionClicked();
    void onBackFromDifficultySelectionClicked();
    void onUndoMoveClicked();

private:
    void setupUI();
    void setupMenuScreen();
    void setupLoginScreen();
    void setupRegisterScreen();
    void setupGameModeScreen();
    void setupSymbolSelectionScreen();
    void setupDifficultySelectionScreen();
    void setupGameScreen();
    void setupHistoryScreen();
    void setupReplayScreen();
    void setupSettingsScreen();
    void switchToScreen(GameState state);
    void resetGame();
    void makeMove(int row, int col);
    void checkGameEnd();
    void updateGameDisplay();
    void updateUserStats(GameResult result);
    void saveGameRecord();
    void loadGameHistory();
    void updateHistoryDisplay();
    void makeAIMove();
    void setGameButtonsEnabled(bool enabled);
    void initializeUserManager();
    void initializeAIPlayer();
    void initializeGameHistory();
    void initializeAutoPlayTimer();
    void applyTheme();
    void saveThemeSettings();
    void loadThemeSettings();
    void startReplay(const GameRecord& record);
    void updateReplayDisplay();
    void resetReplayBoard();
    void applyReplayMove(int moveIndex);
    void showReplayMove(int moveIndex);
    void autoPlayReplay();
    void undoLastMove();
    void updateUndoButton();
    void updateGameModeDisplay();
    void debugTheme();

    // إضافة دوال النافذة المنبثقة
    void setupNotificationSystem();
    void showGameNotification(const QString& message, const QString& type);
    void hideNotification();

    // UI Components
    QStackedWidget* stackedWidget;
    QWidget* menuWidget;
    QWidget* loginWidget;
    QWidget* registerWidget;
    QWidget* gameModeWidget;
    QWidget* symbolSelectionWidget;
    QWidget* difficultySelectionWidget;
    QWidget* gameWidget;
    QWidget* historyWidget;
    QWidget* replayWidget;
    QWidget* settingsWidget;

    // Menu components
    QPushButton* loginButton;
    QPushButton* registerButton;
    QPushButton* settingsButton;
    QLabel* titleLabel;

    // Settings components
    QComboBox* themeComboBox;
    QPushButton* settingsBackButton;
    QLabel* settingsLabel;

    // Login components
    QLineEdit* loginUsernameEdit;
    QLineEdit* loginPasswordEdit;
    QPushButton* loginSubmitButton;
    QPushButton* loginBackButton;
    QPushButton* showRegisterButton;

    // Register components
    QLineEdit* registerUsernameEdit;
    QLineEdit* registerPasswordEdit;
    QLineEdit* registerConfirmPasswordEdit;
    QPushButton* registerSubmitButton;
    QPushButton* registerBackButton;
    QPushButton* showLoginButton;

    // Game mode components
    QPushButton* playerVsPlayerButton;
    QPushButton* playerVsAIButton;
    QPushButton* gameHistoryButton;
    QPushButton* logoutButton;
    QLabel* welcomeLabel;
    QLabel* statsLabel;

    // Symbol selection components
    QRadioButton* symbolXRadio;
    QRadioButton* symbolORadio;
    QButtonGroup* symbolButtonGroup;
    QPushButton* symbolConfirmButton;
    QPushButton* symbolBackButton;
    QLabel* symbolSelectionLabel;

    // Difficulty selection components
    QRadioButton* easyRadio;
    QRadioButton* mediumRadio;
    QRadioButton* hardRadio;
    QButtonGroup* difficultyButtonGroup;
    QPushButton* difficultyConfirmButton;
    QPushButton* difficultyBackButton;
    QLabel* difficultySelectionLabel;

    // Game components
    std::vector<std::vector<QPushButton*>> gameButtons;
    QLabel* gameStatusLabel;
    QLabel* currentPlayerLabel;
    QPushButton* newGameButton;
    QPushButton* backToModeButton;
    QPushButton* undoButton;

    // History components
    QListWidget* historyList;
    QTextEdit* gameDetailsText;
    QPushButton* historyBackButton;
    QPushButton* replayGameButton;

    // Replay components
    std::vector<std::vector<QPushButton*>> replayButtons;
    QLabel* replayStatusLabel;
    QLabel* replayMoveLabel;
    QPushButton* replayNextButton;
    QPushButton* replayPrevButton;
    QPushButton* replayBackButton;
    QPushButton* replayAutoPlayButton;
    QLabel* replayInfoLabel;

    // إضافة مكونات النافذة المنبثقة
    QTimer* notificationTimer;
    QLabel* notificationLabel;

    // Game logic
    std::unique_ptr<GameBoard> gameBoard;
    std::unique_ptr<AIPlayer> aiPlayer;
    std::unique_ptr<UserHashTable> userManager;
    std::unique_ptr<GameHistory> gameHistory;
    std::unique_ptr<GameStateStack> gameStateStack;

    // Game state
    GameState currentState;
    GameMode currentGameMode;
    std::string currentUser;
    char currentPlayer;
    char playerSymbol;
    char secondPlayerSymbol;
    bool gameEnded;
    std::vector<Move> currentGameMoves;
    ThemeMode currentTheme;
    DifficultyLevel currentDifficulty;

    // Replay state
    GameRecord currentReplayGame;
    int currentReplayMoveIndex;
    bool isAutoPlaying;
    QTimer* autoPlayTimer;
    std::vector<std::vector<char>> replayBoard;
};

#endif // TICTACTOEGAME_H
